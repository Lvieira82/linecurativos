document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#triagemForm');
  if (!form) return;

  const steps = [...form.querySelectorAll('.step')];
  const progress = document.querySelector('#progressBar');
  const counter = document.querySelector('#stepCount');
  let current = 0;

  function refresh() {
    steps.forEach((step, index) => step.classList.toggle('active', index === current));
    progress.style.width = `${((current + 1) / steps.length) * 100}%`;
    counter.textContent = `Pergunta ${current + 1} de ${steps.length}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function validateStep() {
    const required = [...steps[current].querySelectorAll('input[required], select[required]')];
    for (const field of required) {
      if ((field.type === 'radio' && !steps[current].querySelector(`input[name="${field.name}"]:checked`)) ||
          (field.type !== 'radio' && !field.value)) {
        alert('Selecione uma resposta para continuar.');
        return false;
      }
    }
    return true;
  }

  form.querySelectorAll('.next').forEach(btn => btn.addEventListener('click', () => {
    if (!validateStep()) return;
    if (current < steps.length - 1) {
      current += 1;
      refresh();
    }
  }));

  form.querySelectorAll('.prev').forEach(btn => btn.addEventListener('click', () => {
    if (current > 0) {
      current -= 1;
      refresh();
    }
  }));

  form.querySelectorAll('.source-toggle').forEach(btn => btn.addEventListener('click', () => {
    const target = document.getElementById(btn.dataset.target);
    if (!target) return;
    target.classList.toggle('open');
    btn.textContent = target.classList.contains('open') ? 'Ocultar referência' : 'Ver referência';
  }));

  const origemRadios = form.querySelectorAll('input[name="origem"]');
  const conditional = form.querySelector('[data-if="origem:queimadura"]');
  origemRadios.forEach(radio => radio.addEventListener('change', () => {
    conditional.classList.toggle('hidden', radio.value !== 'queimadura' || !radio.checked);
  }));

  refresh();
});
