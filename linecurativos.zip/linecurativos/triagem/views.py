from django.shortcuts import render


def inicio(request):
    return render(request, 'triagem/inicio.html')


def triagem(request):
    if request.method != 'POST':
        return render(request, 'triagem/questionario.html')

    def get(name, default=''):
        return request.POST.get(name, default).strip().lower()

    try:
        semanas = int(request.POST.get('semanas', '0'))
    except ValueError:
        semanas = 0

    origem = get('origem')
    cor = get('cor')
    odor = get('odor')
    exsudato = get('exsudato')
    borda = get('borda')
    pele = get('pele')
    satelites = get('satelites')
    diabetes = get('diabetes')
    local = get('local')
    mecanismo_queimadura = get('mecanismo_queimadura')

    cronica = semanas >= 4
    alertas = []
    encaminhamento = 'Avaliação profissional é recomendada para interpretar os achados em conjunto.'
    classe = 'info'

    if diabetes == 'sim':
        alertas.append('Diabetes aumenta a importância de avaliação profissional, especialmente quando a ferida está localizada no pé.')

    if local == 'pe' and diabetes == 'sim':
        alertas.append('Pessoa com diabetes e ferida no pé: procure avaliação profissional, mesmo que a ferida pareça pequena.')

    if odor == 'forte':
        alertas.append('Odor forte é um achado que merece avaliação junto com os demais sinais da ferida; não determina sozinho uma infecção.')

    if cor in {'preta', 'muito_escura'}:
        alertas.append('Tecido muito escuro/preto pode representar tecido desvitalizado e deve ser avaliado profissionalmente.')

    if exsudato in {'muito', 'purulento'}:
        alertas.append('Grande quantidade de secreção ou secreção com aspecto purulento merece avaliação profissional.')

    if satelites == 'sim':
        alertas.append('Alterações ou lesões ao redor da ferida devem ser consideradas na avaliação clínica.')

    if borda in {'grossa', 'enrolada'} and cronica:
        alertas.append('Borda espessada/enrolada em ferida persistente é um achado que merece avaliação profissional.')

    if origem == 'queimadura':
        if mecanismo_queimadura in {'eletrica', 'quimica'}:
            alertas.append('Queimadura elétrica ou química requer avaliação profissional específica.')
        if local in {'face', 'mao', 'pe', 'genital', 'articulacao'}:
            alertas.append('Queimadura em área anatômica especial requer avaliação profissional.')

    if cronica:
        encaminhamento = 'A duração informada é compatível com um fluxo de avaliação de ferida persistente. Recomenda-se avaliação profissional.'
        classe = 'warning'

    if origem == 'queimadura':
        encaminhamento = 'O fluxo identificou uma queimadura. A necessidade de atendimento depende de mecanismo, profundidade, extensão e localização. Não tente remover tecido aderido ou aplicar produtos caseiros.'

    if alertas:
        classe = 'danger'
        encaminhamento = 'Há um ou mais pontos de atenção. Procure avaliação de um profissional de saúde para examinar a ferida.'

    contexto = {
        'cronica': cronica,
        'semanas': semanas,
        'origem': origem,
        'cor': cor,
        'odor': odor,
        'exsudato': exsudato,
        'borda': borda,
        'pele': pele,
        'satelites': satelites,
        'diabetes': diabetes,
        'local': local,
        'mecanismo_queimadura': mecanismo_queimadura,
        'alertas': alertas,
        'encaminhamento': encaminhamento,
        'classe': classe,
    }

    return render(request, 'triagem/resultado.html', contexto)
